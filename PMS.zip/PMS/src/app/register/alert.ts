export interface IAlert {
  type: string;
  message: string;
}