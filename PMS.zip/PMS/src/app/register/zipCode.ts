export class ZipCode {
  constructor(public cityId: number, public code: number) {}
}
